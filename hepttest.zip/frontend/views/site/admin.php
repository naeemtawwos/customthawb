<?php

/* @var $this yii\web\View */

$this->title = 'My Yii Application';
?>
<div class="site-index">

    <div class="jumbotron">
        
    	<a class="btn btn-lg btn-success" href="index.php?r=order-hept/index">Orders</a>
        <a class="btn btn-lg btn-success" href="index.php?r=product">Products</a>
        <a class="btn btn-lg btn-success" href="index.php?r=product/create">Create Product</a>
    </div>

    <div class="body-content">

       
    </div>
</div>
